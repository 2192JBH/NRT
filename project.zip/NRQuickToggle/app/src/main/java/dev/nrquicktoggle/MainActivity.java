package dev.nrquicktoggle;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.view.Gravity;
import android.graphics.Typeface;
import android.text.TextUtils;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView view = new TextView(this);
        view.setText(
                "NR Quick Toggle\n\n" +
                "Adds a Quick Settings tile that changes only the NR allowed-network bit.\n\n" +
                "NR ON:  LTE + LTE_CA + NR\n" +
                "NR OFF: LTE + LTE_CA\n\n" +
                "To add the tile:\n" +
                "1. Pull down Quick Settings twice.\n" +
                "2. Tap Edit (pencil).\n" +
                "3. Find ‘NR Toggle’ and drag it into your active tiles.\n\n" +
                "Root access is required. On first use, approve the su request.\n\n" +
                "The tile indicates NR permission, not whether an NR cell is currently connected.");
        view.setTextSize(17);
        view.setTextColor(0xFF202124);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setPadding(32, 32, 32, 32);
        view.setTypeface(Typeface.DEFAULT);
        view.setEllipsize(TextUtils.TruncateAt.END);
        setContentView(view);
    }
}
