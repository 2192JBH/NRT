package dev.nrquicktoggle;

import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Quick Settings tile: allow/disallow NR while retaining the LTE baseline. */
public class NrTileService extends TileService {
    private static final String TAG = "NRQuickToggle";
    private static final int SIM_SLOT = 0;
    private static final long COMMAND_TIMEOUT_SECONDS = 8;

    private static final String QUERY =
            "cmd phone get-allowed-network-types-for-users -s " + SIM_SLOT;
    // Deliberately use the tested LTE + LTE_CA baseline. These masks do not preserve
    // unrelated 2G/3G/IWLAN permissions if they were enabled before this app is used.
    private static final String NR_ON_MASK = "11000001000000000000";
    private static final String NR_OFF_MASK = "01000001000000000000";

    private static final Set<String> KNOWN_NETWORK_TYPES = new HashSet<>();
    static {
        String[] names = {
                "GSM", "GPRS", "EDGE", "CDMA", "1xRTT", "EVDO_0", "EVDO_A",
                "EVDO_B", "EHRPD", "HSUPA", "HSDPA", "HSPA", "HSPAP", "UMTS",
                "TD_SCDMA", "LTE", "LTE_CA", "NR", "IWLAN", "IDEN"
        };
        for (String name : names) KNOWN_NETWORK_TYPES.add(name);
    }

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean toggleInProgress = new AtomicBoolean(false);

    @Override
    public void onStartListening() {
        super.onStartListening();
        worker.execute(() -> {
            try (RootShell shell = new RootShell()) {
                publishState(parseNrAllowed(shell.run(QUERY)));
            } catch (Exception e) {
                Log.e(TAG, "Initial tile refresh failed; keeping last displayed state", e);
            }
        });
    }

    @Override
    public void onClick() {
        super.onClick();
        if (!toggleInProgress.compareAndSet(false, true)) {
            Log.i(TAG, "Ignoring tap: NR operation already in progress");
            return;
        }

        try {
            worker.execute(() -> {
                try (RootShell shell = new RootShell()) {
                    boolean before = parseNrAllowed(shell.run(QUERY));
                    String mask = before ? NR_OFF_MASK : NR_ON_MASK;
                    String setOutput = shell.run(
                            "cmd phone set-allowed-network-types-for-users -s "
                                    + SIM_SLOT + " " + mask);
                    String lower = setOutput.toLowerCase(java.util.Locale.ROOT);
                    if (lower.contains("failed") || lower.contains("exception")
                            || lower.contains("error")) {
                        throw new IllegalStateException("NR set command reported failure: "
                                + setOutput);
                    }

                    boolean after = parseNrAllowed(shell.run(QUERY));
                    boolean expected = !before;
                    if (after != expected) {
                        throw new IllegalStateException("NR verification mismatch; expected "
                                + expected + " but query returned " + after);
                    }
                    Log.i(TAG, "NR allowed state changed: " + before + " -> " + after);
                    publishState(after);
                } catch (Exception e) {
                    Log.e(TAG, "NR toggle failed; attempting state recovery", e);
                    try (RootShell shell = new RootShell()) {
                        publishState(parseNrAllowed(shell.run(QUERY)));
                    } catch (Exception refreshError) {
                        Log.e(TAG, "Recovery query failed; leaving last displayed state", refreshError);
                    }
                } finally {
                    toggleInProgress.set(false);
                }
            });
        } catch (RuntimeException e) {
            toggleInProgress.set(false);
            Log.e(TAG, "Could not enqueue NR operation", e);
        }
    }

    @Override
    public void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    private void publishState(boolean nrAllowed) {
        getMainExecutor().execute(() -> {
            Tile tile = getQsTile();
            if (tile == null) return;
            tile.setState(nrAllowed ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
            tile.setLabel(nrAllowed ? "NR ON" : "NR OFF");
            tile.setContentDescription(nrAllowed
                    ? "NR is allowed; tap to disable NR"
                    : "NR is not allowed; tap to enable NR");
            tile.updateTile();
        });
    }

    /** Accept only a complete, recognizable pipe-separated network-type list. */
    private static boolean parseNrAllowed(String output) {
        if (output == null || output.trim().isEmpty()) {
            throw new IllegalStateException("Empty allowed-network-types response");
        }
        String trimmed = output.trim();
        String lower = trimmed.toLowerCase(java.util.Locale.ROOT);
        if (lower.contains("exception") || lower.contains("failed") || lower.contains("error")) {
            throw new IllegalStateException("Network query reported failure: " + output);
        }

        String[] parts = trimmed.split("\\|");
        boolean foundNr = false;
        int recognized = 0;
        for (String part : parts) {
            String token = part.trim().toUpperCase(java.util.Locale.ROOT)
                    .replaceAll("^[^A-Z0-9_]+|[^A-Z0-9_]+$", "");
            if (token.isEmpty() || !KNOWN_NETWORK_TYPES.contains(token)) {
                throw new IllegalStateException("Unrecognized network-type token: '" + part
                        + "' in response: " + output);
            }
            recognized++;
            if ("NR".equals(token)) foundNr = true;
        }
        if (recognized == 0) {
            throw new IllegalStateException("No network types in response: " + output);
        }
        return foundNr;
    }

    /**
     * One interactive su process per operation. Commands are sent through stdin; stdout and
     * stderr are merged and drained continuously so neither pipe can block the child process.
     */
    private static final class RootShell implements AutoCloseable {
        private static final String EOF = "\u0000NRQT_EOF";
        private final Process process;
        private final Writer writer;
        private final BlockingQueue<String> lines = new LinkedBlockingQueue<>();
        private int sequence = 0;
        private volatile IOException readerFailure;

        RootShell() throws IOException {
            process = new ProcessBuilder("su").redirectErrorStream(true).start();
            writer = new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8);
            Thread reader = new Thread(() -> {
                try (BufferedReader input = new BufferedReader(new InputStreamReader(
                        process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = input.readLine()) != null) lines.put(line);
                } catch (IOException e) {
                    readerFailure = e;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    lines.offer(EOF);
                }
            }, "NRQuickToggle-RootOutput");
            reader.setDaemon(true);
            reader.start();
        }

        synchronized String run(String command) throws Exception {
            if (!process.isAlive()) throw new IOException("Root shell is not running");
            String marker = "__NRQT_DONE_" + (++sequence) + "__:";
            writer.write(command);
            writer.write("\necho " + marker + "$?\n");
            writer.flush();

            StringBuilder output = new StringBuilder();
            long deadline = System.nanoTime()
                    + TimeUnit.SECONDS.toNanos(COMMAND_TIMEOUT_SECONDS);
            while (true) {
                long remaining = deadline - System.nanoTime();
                if (remaining <= 0) {
                    throw new IOException("Root command timed out: " + command);
                }
                String line = lines.poll(remaining, TimeUnit.NANOSECONDS);
                if (line == null) throw new IOException("Root command timed out: " + command);
                if (EOF.equals(line)) {
                    throw new IOException("Root shell closed unexpectedly", readerFailure);
                }
                if (line.startsWith(marker)) {
                    String status = line.substring(marker.length()).trim();
                    if (!"0".equals(status)) {
                        throw new IOException("Root command exit status " + status
                                + ": " + command + "; output: " + output);
                    }
                    return output.toString().trim();
                }
                if (output.length() > 0) output.append('\n');
                output.append(line);
            }
        }

        @Override
        public void close() {
            try { writer.write("exit\n"); writer.flush(); } catch (Exception ignored) { }
            try { writer.close(); } catch (Exception ignored) { }
            try {
                if (!process.waitFor(500, TimeUnit.MILLISECONDS)) process.destroy();
                if (process.isAlive() && !process.waitFor(500, TimeUnit.MILLISECONDS)) {
                    process.destroyForcibly();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                process.destroyForcibly();
            }
        }
    }
}
