# NR Quick Toggle

A minimal Android Quick Settings tile for rooted Xperia devices. It toggles the NR allowed-network bit using `cmd phone` for SIM slot 0.

## Behavior

- NR ON mask: `11000001000000000000` (NR + LTE + LTE_CA)
- NR OFF mask: `01000001000000000000` (LTE + LTE_CA)
- SIM slot: `0`
- It does not switch preferred network mode or disable LTE.
- The tile reports whether NR is allowed by the user allowed-network-types setting, not whether the phone is currently attached to an NR cell. NSA attachment remains dependent on coverage, modem, and carrier configuration.

**Important mask behavior:** the setter accepts a complete bitmask, not a single-bit patch. These two fixed masks intentionally establish the LTE + LTE_CA baseline. If other RATs (2G/3G/IWLAN) were enabled in the existing user mask, they will not be preserved. Verify this is the intended baseline on the target Xperia before using the tile.

## Root execution

The app starts `su` directly and sends commands through stdin. It does not use `su -c`, matching the interactive-root-shell method tested on the target Xperia. One root shell is reused for the query, set, and verification query in each toggle operation. stdout and stderr are merged and continuously drained. Each command has an 8-second timeout.

## Tile behavior

- Never sets the tile to `UNAVAILABLE` merely because a toggle is running.
- Keeps the last displayed state while a command is in progress or a query fails.
- Ignores additional taps while a toggle is in progress.
- Serializes refresh and toggle work on one worker thread.
- Verifies the resulting NR allowed state after setting the mask.
- On failure, attempts a fresh query and otherwise leaves the last displayed state unchanged.

## Build

Open this folder in Android Studio and build the `app` debug APK. Project configuration: Android Gradle Plugin 8.7.3, compile SDK 35, min SDK 26.

## Install

1. Install the APK and open it once.
2. Add **NR Toggle** from Quick Settings edit mode.
3. Approve the root request if the root manager asks. If the app already has a persistent grant, no new approval should be needed unless that policy changes.
