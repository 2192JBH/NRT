package dev.nrquicktoggle;

import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NrTileService extends TileService {
    private static final String TAG = "NRQuickToggle";
    private static final String QUERY = "cmd phone get-allowed-network-types-for-users -s 0";
    private static final String NR_ON = "cmd phone set-allowed-network-types-for-users -s 0 11000001000000000000";
    private static final String NR_OFF = "cmd phone set-allowed-network-types-for-users -s 0 01000001000000000000";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override
    public void onStartListening() {
        super.onStartListening();
        refreshTile();
    }

    @Override
    public void onClick() {
        super.onClick();
        if (getQsTile() != null) {
            getQsTile().setState(Tile.STATE_UNAVAILABLE);
            getQsTile().setLabel("NR …");
            getQsTile().updateTile();
        }
        worker.execute(() -> {
            try {
                String current = runRoot(QUERY);
                if (current == null || current.trim().isEmpty()
                        || current.toLowerCase().contains("exception")
                        || current.toLowerCase().contains("failed")) {
                    Log.e(TAG, "Could not read allowed network types: " + current);
                    refreshTile();
                    return;
                }
                boolean nrEnabled = hasNr(current);
                String result = runRoot(nrEnabled ? NR_OFF : NR_ON);
                Log.i(TAG, "Toggle result: " + result);
                refreshTile();
            } catch (Exception e) {
                Log.e(TAG, "NR toggle failed", e);
                refreshTile();
            }
        });
    }

    private void refreshTile() {
        worker.execute(() -> {
            try {
                String current = runRoot(QUERY);
                if (current == null || current.trim().isEmpty()) return;
                boolean enabled = hasNr(current);
                getMainExecutor().execute(() -> {
                    Tile tile = getQsTile();
                    if (tile == null) return;
                    tile.setState(enabled ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
                    tile.setLabel(enabled ? "NR ON" : "NR OFF");
                    tile.setContentDescription(enabled
                            ? "NR allowed; tap to disable NR"
                            : "NR disabled; tap to enable NR");
                    tile.updateTile();
                });
            } catch (Exception e) {
                Log.e(TAG, "Tile refresh failed", e);
            }
        });
    }

    private static boolean hasNr(String output) {
        for (String part : output.trim().split("\\|")) {
            if ("NR".equals(part.trim())) return true;
        }
        return false;
    }

    private static String runRoot(String command) throws Exception {
        Process process = new ProcessBuilder("su", "-c", command)
                .redirectErrorStream(true)
                .start();
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (output.length() > 0) output.append('\n');
                output.append(line);
            }
        }
        int exit = process.waitFor();
        if (exit != 0) throw new IllegalStateException("su command exited " + exit + ": " + output);
        return output.toString();
    }
}
