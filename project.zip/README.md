# NR Quick Toggle

A minimal Android Quick Settings tile for rooted Xperia devices. It toggles only the NR bit in the user allowed-network-types mask, using the exact bitmask strings verified on the target device.

- NR ON: `11000001000000000000` (LTE | LTE_CA | NR)
- NR OFF: `01000001000000000000` (LTE | LTE_CA)
- SIM slot: `0`

It does not set GSM/WCDMA or switch the preferred network mode. The tile state reports whether NR is allowed, not whether an NR cell is currently connected.

## Build

Open this folder in Android Studio (AGP 8.7.3, compile SDK 35) and build the `app` debug APK.

## Install and use

1. Install the APK.
2. Open it once.
3. Open Quick Settings edit mode and add **NR Toggle**.
4. Tap the tile and approve the root request from Magisk/KernelSU/etc.

The app runs `su -c` for each query/change. If your root manager denies the app, allow root access for **NR Quick Toggle**.

## Safety / limitations

This is designed for the tested Xperia configuration and SIM slot 0. Do not assume the same bitmasks apply to other devices. The service intentionally fails closed if it cannot read the current mask; it will not guess whether NR is enabled.
